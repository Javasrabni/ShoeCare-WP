import React from 'react'

const LacakPesanan = () => {
  return (
    <div>
      <p>lacak pesanan</p>
    </div>
  )
}

export default LacakPesanan
