import React from 'react'

const Page = () => {
  return (
    <div>
      <p>Manajemen customer</p>
    </div>
  )
}

export default Page
