import React from 'react'

const Page = () => {
  return (
    <div>
      <p>Semua ulasan customer</p>
    </div>
  )
}

export default Page
