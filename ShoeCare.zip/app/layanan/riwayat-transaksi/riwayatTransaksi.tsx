import React from 'react'

const RiwayatTransaksi = () => {
  return (
    <div>
      <p>Riwayat transaksi</p>
    </div>
  )
}

export default RiwayatTransaksi
